/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Health;

/**
 *
 * @author Max
 */
public class City {
    int howmanypeople;
   
    double somkerRate;
    double maleRate;
    double diabetesRate;
    
    double avetotalChlesterol;
    double mintotalChlesterol;
    double maxtotalChlesterol;
    
    double aveHDLChlesterol;
    double minHDLChlesterol;
    double maxHDLChlesterol;
    
    double avebloodPressure;
    int minbloodPressure;
    int maxbloodPressure;
    
    double aveheartBeatPerMinute;
    int minheartBeatPerMinute;
    int maxheartBeatPerMinute;
    
    double aveage;
    int minage;
    int maxage;
    
    double avehealthpoint;
    int minhealthpoint;
    int maxhealthpoint;
    
    double avetenyearrisk;
    int mintenyearrisk;
    int maxtenyearrisk;

    public int getHowmanypeople() {
        return howmanypeople;
    }

    public void setHowmanypeople(int howmanypeople) {
        this.howmanypeople = howmanypeople;
    }

    public double getSomkerRate() {
        return somkerRate;
    }

    public void setSomkerRate(double somkerRate) {
        this.somkerRate = somkerRate;
    }

    public double getMaleRate() {
        return maleRate;
    }

    public void setMaleRate(double maleRate) {
        this.maleRate = maleRate;
    }

    public double getDiabetesRate() {
        return diabetesRate;
    }

    public void setDiabetesRate(double diabetesRate) {
        this.diabetesRate = diabetesRate;
    }

    public double getAvetotalChlesterol() {
        return avetotalChlesterol;
    }

    public void setAvetotalChlesterol(double avetotalChlesterol) {
        this.avetotalChlesterol = avetotalChlesterol;
    }

    public double getMintotalChlesterol() {
        return mintotalChlesterol;
    }

    public void setMintotalChlesterol(double mintotalChlesterol) {
        this.mintotalChlesterol = mintotalChlesterol;
    }

    public double getMaxtotalChlesterol() {
        return maxtotalChlesterol;
    }

    public void setMaxtotalChlesterol(double maxtotalChlesterol) {
        this.maxtotalChlesterol = maxtotalChlesterol;
    }

    public double getAveHDLChlesterol() {
        return aveHDLChlesterol;
    }

    public void setAveHDLChlesterol(double aveHDLChlesterol) {
        this.aveHDLChlesterol = aveHDLChlesterol;
    }

    public double getMinHDLChlesterol() {
        return minHDLChlesterol;
    }

    public void setMinHDLChlesterol(double minHDLChlesterol) {
        this.minHDLChlesterol = minHDLChlesterol;
    }

    public double getMaxHDLChlesterol() {
        return maxHDLChlesterol;
    }

    public void setMaxHDLChlesterol(double maxHDLChlesterol) {
        this.maxHDLChlesterol = maxHDLChlesterol;
    }

    public double getAvebloodPressure() {
        return avebloodPressure;
    }

    public void setAvebloodPressure(double avebloodPressure) {
        this.avebloodPressure = avebloodPressure;
    }

    public int getMinbloodPressure() {
        return minbloodPressure;
    }

    public void setMinbloodPressure(int minbloodPressure) {
        this.minbloodPressure = minbloodPressure;
    }

    public int getMaxbloodPressure() {
        return maxbloodPressure;
    }

    public void setMaxbloodPressure(int maxbloodPressure) {
        this.maxbloodPressure = maxbloodPressure;
    }

    public double getAveheartBeatPerMinute() {
        return aveheartBeatPerMinute;
    }

    public void setAveheartBeatPerMinute(double aveheartBeatPerMinute) {
        this.aveheartBeatPerMinute = aveheartBeatPerMinute;
    }

    public int getMinheartBeatPerMinute() {
        return minheartBeatPerMinute;
    }

    public void setMinheartBeatPerMinute(int minheartBeatPerMinute) {
        this.minheartBeatPerMinute = minheartBeatPerMinute;
    }

    public int getMaxheartBeatPerMinute() {
        return maxheartBeatPerMinute;
    }

    public void setMaxheartBeatPerMinute(int maxheartBeatPerMinute) {
        this.maxheartBeatPerMinute = maxheartBeatPerMinute;
    }

    public double getAveage() {
        return aveage;
    }

    public void setAveage(double aveage) {
        this.aveage = aveage;
    }

    public int getMinage() {
        return minage;
    }

    public void setMinage(int minage) {
        this.minage = minage;
    }

    public int getMaxage() {
        return maxage;
    }

    public void setMaxage(int maxage) {
        this.maxage = maxage;
    }

    public double getAvehealthpoint() {
        return avehealthpoint;
    }

    public void setAvehealthpoint(double avehealthpoint) {
        this.avehealthpoint = avehealthpoint;
    }

    public int getMinhealthpoint() {
        return minhealthpoint;
    }

    public void setMinhealthpoint(int minhealthpoint) {
        this.minhealthpoint = minhealthpoint;
    }

    public int getMaxhealthpoint() {
        return maxhealthpoint;
    }

    public void setMaxhealthpoint(int maxhealthpoint) {
        this.maxhealthpoint = maxhealthpoint;
    }

    public double getAvetenyearrisk() {
        return avetenyearrisk;
    }

    public void setAvetenyearrisk(double avetenyearrisk) {
        this.avetenyearrisk = avetenyearrisk;
    }

    public int getMintenyearrisk() {
        return mintenyearrisk;
    }

    public void setMintenyearrisk(int mintenyearrisk) {
        this.mintenyearrisk = mintenyearrisk;
    }

    public int getMaxtenyearrisk() {
        return maxtenyearrisk;
    }

    public void setMaxtenyearrisk(int maxtenyearrisk) {
        this.maxtenyearrisk = maxtenyearrisk;
    }
    
    
}
