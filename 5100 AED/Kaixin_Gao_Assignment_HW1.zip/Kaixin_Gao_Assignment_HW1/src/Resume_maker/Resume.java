/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Resume_maker;

/**
 *
 * @author Max
 */
public class Resume {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getAffiliation() {
        return affiliation;
    }

    public void setAffiliation(String affiliation) {
        this.affiliation = affiliation;
    }

    public String getVolunteerexp() {
        return volunteerexp;
    }

    public void setVolunteerexp(String volunteerexp) {
        this.volunteerexp = volunteerexp;
    }


    public String getWorkexp1() {
        return workexp1;
    }

    public void setWorkexp1(String workexp1) {
        this.workexp1 = workexp1;
    }

    public String getWorkexp2() {
        return workexp2;
    }

    public void setWorkexp2(String workexp2) {
        this.workexp2 = workexp2;
    }

    public String getWorkexp3() {
        return workexp3;
    }

    public void setWorkexp3(String workexp3) {
        this.workexp3 = workexp3;
    }

    public String getPersonsummary() {
        return personsummary;
    }

    public void setPersonsummary(String personsummary) {
        this.personsummary = personsummary;
    }

    public String getCareerobjective() {
        return careerobjective;
    }

    public void setCareerobjective(String careerobjective) {
        this.careerobjective = careerobjective;
    }
   
    private String name;
    private String email;
    private String address;
    private String address2;
    private String phone;
    private String area;
    private String affiliation;
    private String degree1;
    private String degree2;
    private String volunteerexp;
    private String workexp1;
    private String workexp2;
    private String workexp3;
    private String personsummary;
    private String careerobjective;
    private String image;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    
    
    public String getDegree1() {
        return degree1;
    }

    public void setDegree1(String degree1) {
        this.degree1 = degree1;
    }

    public String getDegree2() {
        return degree2;
    }

    public void setDegree2(String degree2) {
        this.degree2 = degree2;
    }


    

    
    
    
}
