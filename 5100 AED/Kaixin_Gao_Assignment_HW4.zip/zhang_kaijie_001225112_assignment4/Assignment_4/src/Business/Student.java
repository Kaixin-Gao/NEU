/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author zhang
 */
public class Student {
    private String name;
    private int id;
    private Transcript transcript;
    private boolean isEmployment;
    
    
    public Student(){
      transcript=new Transcript();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Transcript getTranscript() {
        return transcript;
    }

    public void setTranscript(Transcript transcript) {
        this.transcript = transcript;
    }

    public boolean isIsEmployment() {
        return isEmployment;
    }

    public void setIsEmployment(boolean isEmployment) {
        this.isEmployment = isEmployment;
    }
    
    
}
