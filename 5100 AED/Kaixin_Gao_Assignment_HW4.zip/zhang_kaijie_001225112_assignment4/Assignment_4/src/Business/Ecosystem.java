/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;
/**
 *
 * @author zhang
 */
public class Ecosystem {
       private String name;
       private int id;
       private ArrayList<University> universityDirectory;
       
       public Ecosystem() {
           universityDirectory=new ArrayList<University>();
       }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    

   

    public ArrayList<University> getUniversityDirectory() {
        return universityDirectory;
    }

    public void setUniversityDirectory(ArrayList<University> universityDirectory) {
        this.universityDirectory = universityDirectory;
    }
    
    
       
    //q1
    
    public double averageGPA() {
         double GPA=0;
           double num=0;
           for (University university :universityDirectory ) {
             for (Student student : university.getUniversityStudentDirectory().getUniversityStudentDirectory()) {
               GPA=GPA+student.getTranscript().getGPA();
               num++;
             }
           }
           return GPA/num;   
    }
    
    //q2
     public double employmentRate() {
            double num1=0;
            double num2=0;
            for (University university :universityDirectory ) {
             for (Student student : university.getUniversityStudentDirectory().getUniversityStudentDirectory()){
                if (student.isIsEmployment()) {
                    num1++;
                }else if (!student.isIsEmployment()) {
                    num2++;
                }
              }
            }
            
            return num1/(num1+num2);
     }
     
     //q3 
     
       public int numOfStudent() {
            int num=0;
             for (University university :universityDirectory ) {
             for (Student student : university.getUniversityStudentDirectory().getUniversityStudentDirectory()){
                 num++;
                 
              }
            }
            return num;
      }
       
       //q4
       
      public int numOfUniversity() {
          int num=0;
            for (University university :universityDirectory) {
                num=num++;
            }
            return num;
      }
      //q5
      public ArrayList<University> allUniversity() {
          return getUniversityDirectory();
      }
    
       
}