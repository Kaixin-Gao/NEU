/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author zhang
 */
public class Semester {
     private ArrayList<Course> semester;
    
    public Semester() {
        semester=new ArrayList<Course>();
    }

    public ArrayList<Course> getSemester() {
        return semester;
    }

    public void setSemester(ArrayList<Course> semester) {
        this.semester = semester;
    }

    
    
    public Course addCourse() {
        Course course=new Course();
        semester.add(course);
        return course;
    }
    
    public void deleteCourse(int id) {
        for (Course course : semester) {
            if (course.getId()==id) {
                semester.remove(course);
            }
        }

    }
}
