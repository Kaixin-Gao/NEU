/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;
/**
 *
 * @author zhang
 */
public class Degree {
    private int level;
    private String requirement;
    
    
    public int getLevel(int level) {
        return level;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getRequirement() {
        return "the overal GPA is at least 3.0";
    }

    public void setRequirement(String requirement) {
        this.requirement = requirement;
    }
    
    

 
    
    
    
   
    
   
}
