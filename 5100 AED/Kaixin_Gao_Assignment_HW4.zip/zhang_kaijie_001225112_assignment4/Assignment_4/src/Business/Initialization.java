/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author zhang
 */
public class Initialization {

    public static Ecosystem initialize() {

       
        Ecosystem ecosystem1 = new Ecosystem();
     

        ecosystem1.setId(1);
        ecosystem1.setName("Education of Boston");

        //  4 univeristy ,  add to ecosystem 
        University university1 = new University();
        university1.setId(001);
        university1.setName("Harvard");
        ecosystem1.getUniversityDirectory().add(university1);

        University university2 = new University();
        university2.setId(002);
        university2.setName("MIT");
        ecosystem1.getUniversityDirectory().add(university2);

        University university3 = new University();
        university3.setId(003);
        university3.setName("NEU");
        ecosystem1.getUniversityDirectory().add(university3);

        University university4 = new University();
        university4.setId(004);
        university4.setName("BU");
        ecosystem1.getUniversityDirectory().add(university4);

        // add college to particular university
        // add college to Harvard  
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                College college = new College();
                college.setName("College of Law");
                college.setId(001);
                university.getCollegeDirectory().add(college);
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                College college = new College();
                college.setName("College of Business");
                college.setId(002);
                university.getCollegeDirectory().add(college);
            }
        }

        // add college to MIT
        for (University university : ecosystem1.getUniversityDirectory()) {

            if (university.getName().equals("MIT")) {
                College college = new College();
                college.setName("College of Engineering");
                college.setId(001);
                university.getCollegeDirectory().add(college);
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                College college = new College();
                college.setName("College of Science");
                college.setId(002);
                university.getCollegeDirectory().add(college);
            }
        }

        // add college to NEU
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                College college = new College();
                college.setName("College of Engineering");
                college.setId(001);
                university.getCollegeDirectory().add(college);
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                College college = new College();
                college.setName("College of Computer Science");
                college.setId(002);
                university.getCollegeDirectory().add(college);
            }
        }

        //add to BU
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                College college = new College();
                college.setName("College of Medical");
                college.setId(001);
                university.getCollegeDirectory().add(college);
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                College college = new College();
                college.setName("College of Engineering");
                college.setId(002);
                university.getCollegeDirectory().add(college);
            }
        }

        /// add department to college 
        //harvard
        //college of law
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        Department department = new Department();
                        department.setName("Financial Law");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        Department department = new Department();
                        department.setName("Criminal Law");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        //college of business
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        Department department = new Department();
                        department.setName("Accounting");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        Department department = new Department();
                        department.setName("MBA");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        // MIT
        // college of engineering
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        Department department = new Department();
                        department.setName("electronic engineering");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        Department department = new Department();
                        department.setName("material engineering");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        // college of science
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        Department department = new Department();
                        department.setName("Math");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        Department department = new Department();
                        department.setName("computer science");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        // NEU
        // college of engineering
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        Department department = new Department();
                        department.setName("information system");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        Department department = new Department();
                        department.setName("electronic engineering");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        //colleeg of computer science
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        Department department2 = new Department();
                        department2.setName("computer science");
                        department2.setId(001);
                        college.getDepartmentDirectory().add(department2);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        Department department1 = new Department();
                        department1.setName("data science");
                        department1.setId(002);
                        college.getDepartmentDirectory().add(department1);
                    }
                }
            }
        }

        // BU
        // college of medical
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        Department department = new Department();
                        department.setName("dentistry");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        Department department = new Department();
                        department.setName("ophthalmology");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        // college of engineering
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        Department department = new Department();
                        department.setName("environment engineering");
                        department.setId(001);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }

        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        Department department = new Department();
                        department.setName("chemical engineering");
                        department.setId(002);
                        college.getDepartmentDirectory().add(department);
                    }
                }
            }
        }
        
        
        
        //add students to the department
        
        //Harvard
        //s1
        Student student1=new Student();
        student1.setId(001);
        student1.setName("Andy");
        student1.setIsEmployment(true);
        student1.getTranscript().setGPA(4.0);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student1);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student1);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student1);
                            }
                        }
                    }
                 }
            }
        }
        
        
        //s2
        Student student2=new Student();
        student2.setId(002);
        student2.setName("Bob");
        student2.setIsEmployment(true);
        student2.getTranscript().setGPA(3.9);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student2);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student2);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student2);
                            }
                        }
                    }
                 }
            }
        }
        
        
        //s3
        Student student3=new Student();
        student3.setId(003);
        student3.setName("Cindy");
        student3.setIsEmployment(true);
        student3.getTranscript().setGPA(3.8);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student3);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student3);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Criminal Law")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student3);
                            }
                        }
                    }
                 }
            }
        }
        
        //s4
        
        Student student4=new Student();
        student4.setId(004);
        student4.setName("David");
        student4.setIsEmployment(true);
        student4.getTranscript().setGPA(3.7);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student4);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student4);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Criminal Law")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student4);
                            }
                        }
                    }
                 }
            }
        }
        
        //s5
        Student student5=new Student();
        student5.setId(005);
        student5.setName("Ella");
        student5.setIsEmployment(true);
        student5.getTranscript().setGPA(3.6);
         
       
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student5);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student5);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Accounting")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student5);
                            }
                        }
                    }
                 }
            }
        }
        
        //s6
        Student student6=new Student();
        student6.setId(006);
        student6.setName("Fisher");
        student6.setIsEmployment(true);
        student6.getTranscript().setGPA(3.5);
        
           for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student6);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student6);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Accounting")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student6);
                            }
                        }
                    }
                 }
            }
        }
        
        //s7
        Student student7=new Student();
        student7.setId(007);
        student7.setName("Green");
        student7.setIsEmployment(true);
        student7.getTranscript().setGPA(3.4);
        
           for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student7);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student7);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("MBA")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student7);
                            }
                        }
                    }
                 }
            }
        }
        
        //s8
        Student student8=new Student();
        student8.setId(010);
        student8.setName("Herry");
        student8.setIsEmployment(false);
        student8.getTranscript().setGPA(2.3);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student8);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student8);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Business")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("MBA")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student8);
                            }
                        }
                    }
                 }
            }
        }
        
        
        
         //MIT
        //s1
        Student student9=new Student();
        student9.setId(011);
        student9.setName("Irvin");
        student9.setIsEmployment(true);
        student9.getTranscript().setGPA(4.0);
        
       for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student9);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student9);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("electronic engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student9);
                            }
                        }
                    }
                 }
            }
        }
        
        //s2
        Student student10=new Student();
        student10.setId(012);
        student10.setName("Jerry");
        student10.setIsEmployment(true);
        student10.getTranscript().setGPA(3.9);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student10);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student10);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("electronic engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student10);
                            }
                        }
                    }
                 }
            }
        }
        
        
        //s3
        Student student11=new Student();
        student11.setId(013);
        student11.setName("Ken");
        student11.setIsEmployment(true);
        student11.getTranscript().setGPA(3.8);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student11);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student11);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("material engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student11);
                            }
                        }
                    }
                 }
            }
        }
        
        //s4
        
        Student student12=new Student();
        student12.setId(014);
        student12.setName("Lerry");
        student12.setIsEmployment(true);
        student12.getTranscript().setGPA(3.7);
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student12);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student12);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("material engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student12);
                            }
                        }
                    }
                 }
            }
        }
       
        
        //s5
        Student student13=new Student();
        student13.setId(015);
        student13.setName("Marry");
        student13.setIsEmployment(true);
        student13.getTranscript().setGPA(3.6);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student13);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student13);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Math")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student13);
                            }
                        }
                    }
                 }
            }
        }
        
        //s6
        Student student14=new Student();
        student14.setId(016);
        student14.setName("Nancy");
        student14.setIsEmployment(true);
        student14.getTranscript().setGPA(3.5);
          for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student14);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student14);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Math")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student14);
                            }
                        }
                    }
                 }
            }
        }
       
        
        //s7
        Student student15=new Student();
        student15.setId(017);
        student15.setName("Oscar");
        student15.setIsEmployment(true);
        student15.getTranscript().setGPA(3.4);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student15);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student15);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("computer science")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student15);
                            }
                        }
                    }
                 }
            }
        }
        
        //s8
        Student student16=new Student();
        student16.setId(012);
        student16.setName("Penny");
        student16.setIsEmployment(true);
        student16.getTranscript().setGPA(4.0);
            for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student16);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student16);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("MIT")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("computer science")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student16);
                            }
                        }
                    }
                 }
            }
        }
        
        
        
        // NEU
        //s1
        Student student17=new Student();
        student17.setId(012);
        student17.setName("Quency");
        student17.setIsEmployment(true);
        student17.getTranscript().setGPA(4.0);
        
            for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student17);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student17);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("information system")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student17);
                            }
                        }
                    }
                 }
            }
        }
        
        
         //s2
        Student student18=new Student();
        student18.setId(012);
        student18.setName("Ray");
        student18.setIsEmployment(true);
        student18.getTranscript().setGPA(4.0);
        
          for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student18);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student18);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("information system")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student18);
                            }
                        }
                    }
                 }
            }
        }
         //s3
        Student student19=new Student();
        student19.setId(012);
        student19.setName("Steve");
        student19.setIsEmployment(true);
        student19.getTranscript().setGPA(4.0);
        
          for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student19);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student19);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("electronic engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student19);
                            }
                        }
                    }
                 }
            }
        }
        
         //s4
        Student student20=new Student();
        student20.setId(012);
        student20.setName("Tim");
        student20.setIsEmployment(true);
        student20.getTranscript().setGPA(4.0);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student20);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student20);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("electronic engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student20);
                            }
                        }
                    }
                 }
            }
        }
        
         //s5
        Student student21=new Student();
        student21.setId(012);
        student21.setName("Unique");
        student21.setIsEmployment(true);
        student21.getTranscript().setGPA(3.8);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student21);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student21);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("computer science")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student21);
                            }
                        }
                    }
                 }
            }
        }
        
         //s6
        Student student22=new Student();
        student22.setId(012);
        student22.setName("Victor");
        student22.setIsEmployment(true);
        student22.getTranscript().setGPA(3.8);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student22);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student22);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("computer science")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student22);
                            }
                        }
                    }
                 }
            }
        }
        
         //s7
        Student student23=new Student();
        student23.setId(012);
        student23.setName("Wendy");
        student23.setIsEmployment(true);
        student23.getTranscript().setGPA(3.8);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student23);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student23);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("data science")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student23);
                            }
                        }
                    }
                 }
            }
        }
        
        
         //s8
        Student student24=new Student();
        student24.setId(012);
        student24.setName("Xmy");
        student24.setIsEmployment(true);
        student24.getTranscript().setGPA(3.8);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student24);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student24);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("NEU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Computer Science")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("data science")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student24);
                            }
                        }
                    }
                 }
            }
        }
        
        
        
        
        // BU
        //S1
        Student student25=new Student();
        student25.setId(012);
        student25.setName("Yellow");
        student25.setIsEmployment(true);
        student25.getTranscript().setGPA(3.3);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student25);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student25);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("dentistry")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student25);
                            }
                        }
                    }
                 }
            }
        }
        //s2
        Student student26=new Student();
        student26.setId(012);
        student26.setName("Zack");
        student26.setIsEmployment(true);
        student26.getTranscript().setGPA(3.3);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student26);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student26);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("dentistry")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student26);
                            }
                        }
                    }
                 }
            }
        }
        
         //s3
        Student student27=new Student();
        student27.setId(012);
        student27.setName("Allen");
        student27.setIsEmployment(true);
        student27.getTranscript().setGPA(3.3);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student27);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student27);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("ophthalmology")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student27);
                            }
                        }
                    }
                 }
            }
        }
        
         //s4
        Student student28=new Student();
        student28.setId(012);
        student28.setName("Berry");
        student28.setIsEmployment(true);
        student28.getTranscript().setGPA(3.3);
        
       for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student28);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student28);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Medical")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("ophthalmology")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student28);
                            }
                        }
                    }
                 }
            }
        }
        
         //s5
        Student student29=new Student();
        student29.setId(012);
        student29.setName("Cris");
        student29.setIsEmployment(true);
        student29.getTranscript().setGPA(3.1);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student29);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student29);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("environment engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student29);
                            }
                        }
                    }
                 }
            }
        }
        
         //s6
        Student student30=new Student();
        student30.setId(012);
        student30.setName("Dale");
        student30.setIsEmployment(true);
        student30.getTranscript().setGPA(3.1);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student30);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student30);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("environment engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student30);
                            }
                        }
                    }
                 }
            }
        }
        
         //s7
        Student student31=new Student();
        student31.setId(012);
        student31.setName("Enternal");
        student31.setIsEmployment(true);
        student31.getTranscript().setGPA(3.1);
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student31);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student31);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("chemical engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student31);
                            }
                        }
                    }
                 }
            }
        }
        
         //s8
        Student student32=new Student();
        student32.setId(012);
        student32.setName("Fy");
        student32.setIsEmployment(true);
        student32.getTranscript().setGPA(3.1);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                university.getUniversityStudentDirectory().getUniversityStudentDirectory().add(student32);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        college.getCollegeStudentDirectory().getCollegeStudentDirectory().add(student32);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("BU")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Engineering")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("chemical engineering")) {
                                department.getDepartmentStudentDirectory().getDepartmentStudentDirectory().add(student32);
                            }
                        }
                    }
                 }
            }
        }
        
        //add faculty
        
        Faculty faculty1=new Faculty();
        faculty1.setId(001);
        faculty1.setName("Andy");
        faculty1.setIsPHD(true);
        faculty1.setIsPartTime(false);
        
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getFacultyDirectory().add(faculty1);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getFacultyDirectory().add(faculty1);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getFacultyDirectory().add(faculty1);
                            }
                        }
                    }
                 }
            }
        }
        
        Faculty faculty2=new Faculty();
        faculty2.setId(001);
        faculty2.setName("Andy");
        faculty2.setIsPHD(true);
        faculty2.setIsPartTime(true);
        
       for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getFacultyDirectory().add(faculty2);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getFacultyDirectory().add(faculty2);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getFacultyDirectory().add(faculty2);
                            }
                        }
                    }
                 }
            }
        }
        
        
        //add staff
        Staff staff1=new Staff();
        staff1.setId(001);
        staff1.setName("Andy");
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                university.getStaffDirectory().add(staff1);
            }
        }
         for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        college.getStaffDirectory().add(staff1);
                    }
                }
            }
        }
         
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university.getName().equals("Harvard")) {
                 for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getStaffDirectory().add(staff1);
                            }
                        }
                    }
                 }
            }
        }
        
        
        // add course
        Course course1=new Course();
        course1.setId(001);
        course1.setName("Tax Law");
        course1.setPrice(1000);
        course1.setCredits(4);
        course1.setCourseType("elective");
        course1.setCapacity(2);
        course1.setRequirements("at least 3.0");
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university1.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getDepartmentCourseCatalog().getDepartmentCourseCatalog().add(course1);
                            }
                        }
                    }
                }
            }
        }
        
        
        Course course2=new Course();
        course2.setId(001);
        course2.setName("Basic Law");
        course2.setPrice(1500);
        course2.setCredits(4);
        course2.setCourseType("core");
        course2.setCapacity(2);
        course2.setRequirements("at least 3.0");
        
        for (University university : ecosystem1.getUniversityDirectory()) {
            if (university1.getName().equals("Harvard")) {
                for (College college : university.getCollegeDirectory()) {
                    if (college.getName().equals("College of Law")) {
                        for (Department department : college.getDepartmentDirectory()) {
                            if (department.getName().equals("Financial Law")) {
                                department.getDepartmentCourseCatalog().getDepartmentCourseCatalog().add(course2);
                            }
                        }
                    }
                }
            }
        }
        
        
        
        return ecosystem1;
  }
}


