/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author zhang
 */
public class University {
      private String name;
      private int id;
      private int capacity;
      private ArrayList<Faculty> facultyDirectory;
      private ArrayList<Staff> staffDirectory;
      private ArrayList<College> collegeDirectory;
      private UniversityStudentDirectory universityStudentDirectory;
      
      public University() {
          facultyDirectory=new ArrayList<Faculty>();
          staffDirectory=new ArrayList<Staff>();
          collegeDirectory=new ArrayList<College>();
          universityStudentDirectory=new UniversityStudentDirectory();
      }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public ArrayList<Faculty> getFacultyDirectory() {
        return facultyDirectory;
    }

    public void setFacultyDirectory(ArrayList<Faculty> facultyDirectory) {
        this.facultyDirectory = facultyDirectory;
    }

    public ArrayList<Staff> getStaffDirectory() {
        return staffDirectory;
    }

    public void setStaffDirectory(ArrayList<Staff> staffDirectory) {
        this.staffDirectory = staffDirectory;
    }

    public ArrayList<College> getCollegeDirectory() {
        return collegeDirectory;
    }

    public void setCollegeDirectory(ArrayList<College> collegeDirectory) {
        this.collegeDirectory = collegeDirectory;
    }

    public UniversityStudentDirectory getUniversityStudentDirectory() {
        return universityStudentDirectory;
    }

    public void setUniversityStudentDirectory(UniversityStudentDirectory universityStudentDirectory) {
        this.universityStudentDirectory = universityStudentDirectory;
    }
      
    //q1
    public double averageGPA() {
         double GPA=0;
           double num=0;
           for (Student student :universityStudentDirectory.getUniversityStudentDirectory() ) {
               GPA=GPA+student.getTranscript().getGPA();
               num++;
           }
           return GPA/num;   
    }
    
    //q2
    
     public double employmentRate() {
            double num1=0;
            double num2=0;
            for (Student student :universityStudentDirectory.getUniversityStudentDirectory()) {
                if (student.isIsEmployment()) {
                    num1++;
                }else if (!student.isIsEmployment()) {
                    num2++;
                }
            }
            return num1/(num1+num2);
     }
     
     //q3 faculty/student
     
     public double ratio1() {
            double num1=0;
            double num2=0;
            
            for (Student student : universityStudentDirectory.getUniversityStudentDirectory()){
                num1++;
            }
            for (Faculty faculty :facultyDirectory) {
                num2++;
            }
            return num2/num1;
     }
     
     //q4
     
      public int numOfStudent() {
            int num=0;
            for (Student student :universityStudentDirectory.getUniversityStudentDirectory()) {
                num++;
            }
            return num;
      }
      
     //q5 faculty/satff
      
      public double radio2() {
            double num1=0;
            double num2=0;
            
            for (Faculty faculty :facultyDirectory) {
                num1++;
            }
            for (Staff staff : staffDirectory) {
                num2++;
            }
            return num2/num1;
      }
      
      //q6 isPartTime
         public double radio3() {
            double num1=0;
            double num2=0;
            for (Faculty faculty : facultyDirectory) {
                if (faculty.isIsPartTime()) {
                    num1++;
                }else if (!faculty.isIsPartTime()) {
                    num2++;
                }
            }
            return num2/(num1+num2);
        }
         
      //q7 isPHD
        public double radio4() {
            double num1=0;
            double num2=0;
            for (Faculty faculty :facultyDirectory) {
                if (faculty.isIsPHD()) {
                    num1++;
                }else if (!faculty.isIsPHD()) {
                    num2++;
                }
            }
            return num1/(num1+num2);
        }
        
     //q8 学校的所有学院 getCollegeDirectory();
        
          public ArrayList<College> allCollege() {
              return getCollegeDirectory();
          }
        
     //q9 学校的所有专业  
        
          public List<Department> allDepartment() {
              List<Department> allDepartment=new ArrayList<Department>();
              for (College college :collegeDirectory) {
                  for (Department department : college.getDepartmentDirectory()) {
                      allDepartment.add(department);
                  }
              }
              return allDepartment;
          }
     //q10 price of course
          
          public double priceForCourse () {
              double num1=0;
              double num2=0;
              for (College college :collegeDirectory) {
                  for (Department department :college.getDepartmentDirectory()) {
                      for (Course course :department.getDepartmentCourseCatalog().getDepartmentCourseCatalog()) {
                          num1++;
                          num2=num2+course.getPrice();
                      }
                  }
              }
              
              return num2/num1;
          }
      
}
