/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author zhang
 */
public class Department {
      private String name;
      private int id;
      private int capacity;
      private Degree degree;
      private ArrayList<Faculty> facultyDirectory;
      private ArrayList<Staff> staffDirectory;
      private DepartmentCourseCatalog departmentCourseCatalog;
      private DepartmentCourseSchedual departmentCourseSchedual;
      private DepartmentStudentDirectory departmentStudentDirectory;
      
      public Department() {
          degree=new Degree();
          staffDirectory=new ArrayList<Staff>();
          facultyDirectory=new ArrayList<Faculty>();
       departmentCourseSchedual=new DepartmentCourseSchedual();
       departmentCourseCatalog=new DepartmentCourseCatalog();
       departmentStudentDirectory=new DepartmentStudentDirectory();
      }
     

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public DepartmentCourseCatalog getDepartmentCourseCatalog() {
        return departmentCourseCatalog;
    }

    public void setDepartmentCourseCatalog(DepartmentCourseCatalog departmentCourseCatalog) {
        this.departmentCourseCatalog = departmentCourseCatalog;
    }

    public DepartmentCourseSchedual getDepartmentCourseSchedual() {
        return departmentCourseSchedual;
    }

    public void setDepartmentCourseSchedual(DepartmentCourseSchedual departmentCourseSchedual) {
        this.departmentCourseSchedual = departmentCourseSchedual;
    }

    public DepartmentStudentDirectory getDepartmentStudentDirectory() {
        return departmentStudentDirectory;
    }

    public void setDepartmentStudentDirectory(DepartmentStudentDirectory departmentStudentDirectory) {
        this.departmentStudentDirectory = departmentStudentDirectory;
    }

    public Degree getDegree() {
        return degree;
    }

    public void setDegree(Degree degree) {
        this.degree = degree;
    }

    public ArrayList<Faculty> getFacultyDirectory() {
        return facultyDirectory;
    }

    public void setFacultyDirectory(ArrayList<Faculty> facultyDirectory) {
        this.facultyDirectory = facultyDirectory;
    }

    public ArrayList<Staff> getStaffDirectory() {
        return staffDirectory;
    }

    public void setStaffDirectory(ArrayList<Staff> staffDirectory) {
        this.staffDirectory = staffDirectory;
    }
    
    
   
     // q1 : .getDepartmentCourseCatalog().  getDepartmentCourseCatalog();  返回course的array list
     // q2:  .getDepartmentStudentDirectory().getDepartmentCourseSchedual(); 返回arraylist<arrsylist<course>>
     // q3:
        public Course coreCourse(int id) {
            for (Course course : departmentCourseCatalog.getDepartmentCourseCatalog()) {
                if (course.getId()==id) {
                    if (course.getCourseType()=="core") {
                        return course;
                    }
                }
            }
            return null;
        }
        
        public Course electiveCourse(int id) {
            for (Course course : departmentCourseCatalog.getDepartmentCourseCatalog()) {
                if (course.getId()==id) {
                    if (course.getCourseType()=="elective") {
                        return course;
                    }
                }
            }
            return null;
        }
        
       
        
        // q4  getDegree().getRequirement()
        
        //q5
        
        public int empty() {
            int num=0;
            for (Student student : departmentStudentDirectory.getDepartmentStudentDirectory()) {
                num++;
            }
            return capacity-num;
        }
        
        // q6
        public double ratio1() {
            double num1=0;
            double num2=0;
            
            for (Student student :departmentStudentDirectory.getDepartmentStudentDirectory() ){
                num1++;
            }
            for (Faculty faculty :facultyDirectory) {
                num2++;
            }
            return num2/num1;
        }
        
        // q7
        
        public double avaergeNum () {
            double num1=0;
            double num2=0;
            for (Course course :departmentCourseCatalog.getDepartmentCourseCatalog()){
                num1++;
                num2=num2+course.getCapacity();
            }
            return num2/num1;
        }
        
        public int largest() {
            int num=0;
            for (Course course :departmentCourseCatalog.getDepartmentCourseCatalog()) {
                num=Math.max(num, course.getCapacity());
            }
            return num;
        }
        public int smallest() {
             int num=Integer.MAX_VALUE;
            for (Course course :departmentCourseCatalog.getDepartmentCourseCatalog()) {
                num=Math.min(num, course.getCapacity());
            }
            return num;
        }
        
        //q8
        
        public int numOfStudent() {
            int num=0;
            for (Student student :departmentStudentDirectory.getDepartmentStudentDirectory()) {
                num++;
            }
            return num;
        }
        
        //q9
        
        public double radio2() {
            double num1=0;
            double num2=0;
            
            for (Faculty faculty :facultyDirectory) {
                num1++;
            }
            for (Staff staff : staffDirectory) {
                num2++;
            }
            return num2/num1;
        }
        
        //q10
        
        public double radio3() {
            double num1=0;
            double num2=0;
            for (Faculty faculty : facultyDirectory) {
                if (faculty.isIsPartTime()) {
                    num1++;
                }else if (!faculty.isIsPartTime()) {
                    num2++;
                }
            }
            return num2/num1;
        }
        
        //q11
        
        public double radio4() {
            double num1=0;
            double num2=0;
            for (Faculty faculty :facultyDirectory) {
                if (faculty.isIsPHD()) {
                    num1++;
                }else if (!faculty.isIsPHD()) {
                    num2++;
                }
            }
            return num1/(num1+num2);
        }
        
        // q12
        public double averageGPA() {
        
           double GPA=0;
           double num=0;
           for (Student student :departmentStudentDirectory.getDepartmentStudentDirectory() ) {
               GPA=GPA+student.getTranscript().getGPA();
               num++;
           }
           return GPA/num;         
    
        }
        
        //q13
        
        public double employmentRate() {
            int num1=0;
            int num2=0;
            for (Student student :departmentStudentDirectory.getDepartmentStudentDirectory()) {
                if (student.isIsEmployment()) {
                    num1++;
                }else if (!student.isIsEmployment()) {
                    num2++;
                }
            }
            return num1/(num1+num2);
        }
}
        
        
        
        
        
      




