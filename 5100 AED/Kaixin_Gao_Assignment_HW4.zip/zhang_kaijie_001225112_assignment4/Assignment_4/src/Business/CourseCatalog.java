/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;
/**
 *
 * @author zhang
 */
public class CourseCatalog {
    private ArrayList<Course> courseCatalog;
    
    public CourseCatalog() {
        courseCatalog=new ArrayList<Course>();
    }

    public ArrayList<Course> getCourseCatalog() {
        return courseCatalog;
    }

    public void setCourseCatalog(ArrayList<Course> courseCatalog) {
        this.courseCatalog = courseCatalog;
    }
    
    public Course addCourse() {
        Course course=new Course();
        courseCatalog.add(course);
        return course;
    }
    
    public void deleteCourse(int id) {
        for (Course course : courseCatalog) {
            if (course.getId()==id) {
                courseCatalog.remove(course);
            }
        }

    }
}
