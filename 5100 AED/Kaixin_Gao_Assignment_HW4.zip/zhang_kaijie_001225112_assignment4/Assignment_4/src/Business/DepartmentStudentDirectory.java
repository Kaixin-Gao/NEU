/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.ArrayList;
/**
 *
 * @author zhang
 */
public class DepartmentStudentDirectory {
       private ArrayList<Student> departmentStudentDirectory;
       
       public DepartmentStudentDirectory() {
           departmentStudentDirectory=new ArrayList<Student>();
       }

    public ArrayList<Student> getDepartmentStudentDirectory() {
        return departmentStudentDirectory;
    }

    public void setDepartmentStudentDirectory(ArrayList<Student> departmentStudentDirectory) {
        this.departmentStudentDirectory = departmentStudentDirectory;
    }
       
    public Student addStudents() {
        Student student=new Student();
        departmentStudentDirectory.add(student);
        return student;
    }
    
    public Student search(String name) {
        for (Student student : departmentStudentDirectory) {
            if (student.getName().equals(name)) {
                return student;
            }
        }
        return null;
    }
}
