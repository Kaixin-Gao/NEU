/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author zhang
 */
public class UniversityStudentDirectory {
         private ArrayList<Student> universityStudentDirectory;
       
       public UniversityStudentDirectory() {
          universityStudentDirectory=new ArrayList<Student>();
       }

    public ArrayList<Student> getUniversityStudentDirectory() {
        return universityStudentDirectory;
    }

    public void setUniversityStudentDirectory(ArrayList<Student> universityStudentDirectory) {
        this.universityStudentDirectory = universityStudentDirectory;
    }

    

    
       
    public Student addStudents() {
        Student student=new Student();
        universityStudentDirectory.add(student);
        return student;
    }
    
    public Student search(String name) {
        for (Student student : universityStudentDirectory) {
            if (student.getName().equals(name)) {
                return student;
            }
        }
        return null;
    }
}
