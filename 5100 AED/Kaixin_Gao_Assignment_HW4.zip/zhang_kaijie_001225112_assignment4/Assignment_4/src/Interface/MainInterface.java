/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;
import Business.College;
import Business.Course;
import Business.Department;
import Business.Ecosystem;
import Business.Initialization;
import Business.Student;
import Business.University;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author zhang
 */
public class MainInterface {
    public static void main(String[] args) {
        // TODO code application logic here

        System.out.println("*********Welcome to the EDUCATION LEVEL ECOSYSTEM*************** ");
        System.out.println("*********Please enter the choice below for Reports*************** ");
        System.out.println("1.ECOSYSTEM LEVEL REPORTS");
        System.out.println("2.UNIVERSITY LEVEL REPORTS");
        System.out.println("3.COLLEGE LEVEL REPORTS");
        System.out.println("4.DEPARTMENT ECO SYSTEM REPORTS");

        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.println("Enter a choice. Please enter a number for example just enter 1 for department level reports");
        int choice = reader.nextInt(); // Scans the next token of the input as an int.
        
        Ecosystem ecosystem = Initialization.initialize();
       
        
         switch (choice) {
             case 1:
                String name=ecosystem.getName();
                int id =ecosystem.getId();
                ArrayList<University> list=ecosystem.getUniversityDirectory();
                
                System.out.println("***************EDUCATION ECO SYSTEM LEVEL REPORTS STARTS******************");
                System.out.println("ecosystem information");
                System.out.println("ecosystem name is " +name );
                System.out.println("ecosystem id is " +id);
                System.out.println("number of university in the ecosystem is " +list.size());
                System.out.println("all the universities in the ecosystem as below");
               
                 for (int i=0;i<list.size();i++) {
                   System.out.println(list.get(i).getName());
                 }      
                System.out.println("number of students in this ecosystem is " + ecosystem.numOfStudent());
                System.out.println("average GPA is " +ecosystem.averageGPA());
                System.out.println("employment rate is " +ecosystem.employmentRate());
                System.out.println("***************EDUCATION ECO SYSTEM LEVEL REPORT ENDS******************");
                break;
                
             case 2:
                System.out.println("***************UNIVERSITY LEVEL REPORTS STARTS******************");
                System.out.println("the university name is " +ecosystem.getUniversityDirectory().get(0).getName());
                System.out.println("number of students in the university is " +ecosystem.getUniversityDirectory().get(0).numOfStudent());
                System.out.println("averge GPA in the university is " +ecosystem.getUniversityDirectory().get(0).averageGPA());
                System.out.println("the employment rate in the university is " +ecosystem.getUniversityDirectory().get(0).employmentRate());
                System.out.println("the college in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(0).getCollegeDirectory()) {
                    System.out.println(college.getName());
                }
                System.out.println("the department in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(0).getCollegeDirectory()) {
                    for (Department department :college.getDepartmentDirectory()) {
                        System.out.println(department.getName());
                    }
                }
                System.out.println("the ratio of faculty/students is " +ecosystem.getUniversityDirectory().get(0).ratio1());
                System.out.println("the ratio of the faculty/staff is " +ecosystem.getUniversityDirectory().get(0).radio2());
                System.out.println("the percentage of part time for faculty is " + ecosystem.getUniversityDirectory().get(0).radio3());
                System.out.println("the percentage of PHD for professor is " +ecosystem.getUniversityDirectory().get(0).radio4());
                System.out.println("the average price for course is " +ecosystem.getUniversityDirectory().get(0).priceForCourse() );
                System.out.println("***************UNIVERSITY LEVEL REPORT ENDS******************");
                
                System.out.println("***************UNIVERSITY LEVEL REPORTS STARTS******************");
                System.out.println("the university name is " +ecosystem.getUniversityDirectory().get(1).getName());
                System.out.println("number of students in the university is " +ecosystem.getUniversityDirectory().get(1).numOfStudent());
                System.out.println("averge GPA in the university is " +ecosystem.getUniversityDirectory().get(1).averageGPA());
                System.out.println("the employment rate in the university is " +ecosystem.getUniversityDirectory().get(1).employmentRate());
                System.out.println("the college in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(1).getCollegeDirectory()) {
                    System.out.println(college.getName());
                }
                System.out.println("the department in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(1).getCollegeDirectory()) {
                    for (Department department :college.getDepartmentDirectory()) {
                        System.out.println(department.getName());
                    }
                }
                System.out.println("***************UNIVERSITY LEVEL REPORT ENDS******************");
                
                System.out.println("***************UNIVERSITY LEVEL REPORTS STARTS******************");
                System.out.println("the university name is " +ecosystem.getUniversityDirectory().get(2).getName());
                System.out.println("number of students in the university is " +ecosystem.getUniversityDirectory().get(2).numOfStudent());
                System.out.println("averge GPA in the university is " +ecosystem.getUniversityDirectory().get(2).averageGPA());
                System.out.println("the employment rate in the university is " +ecosystem.getUniversityDirectory().get(2).employmentRate());
                System.out.println("the college in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(2).getCollegeDirectory()) {
                    System.out.println(college.getName());
                }
                System.out.println("the department in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(2).getCollegeDirectory()) {
                    for (Department department :college.getDepartmentDirectory()) {
                        System.out.println(department.getName());
                    }
                }
                System.out.println("***************UNIVERSITY LEVEL REPORT ENDS******************");
                
                  System.out.println("***************UNIVERSITY LEVEL REPORTS STARTS******************");
                System.out.println("the university name is " +ecosystem.getUniversityDirectory().get(3).getName());
                System.out.println("number of students in the university is " +ecosystem.getUniversityDirectory().get(3).numOfStudent());
                System.out.println("averge GPA in the university is " +ecosystem.getUniversityDirectory().get(3).averageGPA());
                System.out.println("the employment rate in the university is " +ecosystem.getUniversityDirectory().get(3).employmentRate());
                System.out.println("the college in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(3).getCollegeDirectory()) {
                    System.out.println(college.getName());
                }
                System.out.println("the department in the university is below");
                for (College college :ecosystem.getUniversityDirectory().get(3).getCollegeDirectory()) {
                    for (Department department :college.getDepartmentDirectory()) {
                        System.out.println(department.getName());
                    }
                }
                System.out.println("***************UNIVERSITY LEVEL REPORT ENDS******************");
                break;
                
            case 3:
                // just one 
                System.out.println("**************COLLEGE LEVEL REPORTS STARTS******************");
                System.out.println("information from college level for Havard University");
                System.out.println("the information for College of Law in Havard University");
                System.out.println("the department in the college of law is below");
                for (Department department :ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory()) {
                    System.out.println(department.getName());
                }
                
                System.out.println("the number of students in College of Law is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).numOfStudent());
                System.out.println("the average GPA for college of law is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).averageGPA());
                System.out.println("the employment rate for college of law is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).employmentRate());
                System.out.println("the average number of students per course is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).averageNum());
                System.out.println("the number of students for the smallest class is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).smallest());
                System.out.println("the number of students for the largest class is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).largest());
                System.out.println("the ratio of faculty to students is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).ratio1());
                System.out.println("the ratio of the faculty to staff is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).radio2());
                System.out.println("the percentage of part time for faculty is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).radio3());
                System.out.println("the percentage of PHD for faculty is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).radio4());
                System.out.println("***************COLLEGE LEVEL REPORT ENDS******************");
                break;
             
            case 4:
                System.out.println("***********DEPARTMENT LEVEL REPORTS STARTS******************");
                System.out.println("the information from department level for college of law in Harvard university");
                System.out.println("the information about Financial law department");
                System.out.println("the average GPA of the financial law department is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).averageGPA());
                System.out.println("the employment rate of the financial law department is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).employmentRate());
                System.out.println("the course and its requirements in the department as below");
                for (Course course :ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).getDepartmentCourseCatalog().getDepartmentCourseCatalog()) {
                     System.out.println(course.getName());
                     System.out.println(course.getRequirements());
                }
                System.out.println("the core course is below ");
                for (Course course :ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).getDepartmentCourseCatalog().getDepartmentCourseCatalog()) {
                    if (course.getCourseType().equals("core")) {
                        System.out.println(course.getName());
                    }
                }
                System.out.println("the elective course is below");
                 for (Course course :ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).getDepartmentCourseCatalog().getDepartmentCourseCatalog()) {
                    if (course.getCourseType().equals("elective")) {
                        System.out.println(course.getName());
                    }
                }
                System.out.println("the degree requirement is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).getDegree().getRequirement() );
                System.out.println("the number of students is " + ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).numOfStudent());
                System.out.println("the ratio of faculty/students is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).ratio1());
                System.out.println("the average number of students per course is " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).avaergeNum());
                System.out.println("the smallest class have studnets " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).smallest());
                System.out.println("the largest class have students " +ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).largest());
                System.out.println("the ratio of staff/faculty is " + ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).radio2());
                System.out.println("the percentage of part time for faculty is " + ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).radio3());
                System.out.println("the ratio of percentage of PHD for faculty is " + ecosystem.getUniversityDirectory().get(0).getCollegeDirectory().get(0).getDepartmentDirectory().get(0).radio4());
                System.out.println("***************DEPARTMENT LEVEL REPORT ENDS******************");
                break;
         }
    }
}
